﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zakmob : MonoBehaviour
{

    public GameObject mypdl;
    // Start is called before the first frame update
    void Start()
    {
        mypdl.SetActive(false);
    }

    

    public void vkl()
    {
        mypdl.SetActive(false);
    }
}
